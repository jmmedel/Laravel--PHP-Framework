<div class="top-bar">
  <div class="row">
    <div class="top-bar-left">
      <ul class="menu">
        <li class="menu-text">PhotoShow</li>
        <li><a href="/">Home</a></li>
        <li><a href="/albums/create">Create Album</a></li>
      </ul>
    </div>
  </div>
</div>
