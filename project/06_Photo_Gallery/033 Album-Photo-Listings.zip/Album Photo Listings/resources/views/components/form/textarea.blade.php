<label>
  {{Form::label($name)}}
  {{Form::textarea($name, $value, $attributes)}}
</label>
