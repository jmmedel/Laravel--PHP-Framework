<label>
  {{Form::label($name)}}
  {{Form::text($name, $value, $attributes)}}
</label>
