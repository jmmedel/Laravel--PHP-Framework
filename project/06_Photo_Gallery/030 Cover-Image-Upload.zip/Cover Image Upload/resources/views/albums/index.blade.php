@extends('layouts.app')

@section('content')
  <h3>Albums</h3>
@endsection
