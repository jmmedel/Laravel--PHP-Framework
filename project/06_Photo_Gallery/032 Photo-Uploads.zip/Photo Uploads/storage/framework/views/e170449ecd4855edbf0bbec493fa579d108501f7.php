<?php $__env->startSection('content'); ?>
  <h1><?php echo e($album->name); ?></h1>
  <a class="button secondary" href="/">Go Back</a>
  <a class="button" href="/photos/create/<?php echo e($album->id); ?>">Upload Photo To Album</a>
  <hr>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>