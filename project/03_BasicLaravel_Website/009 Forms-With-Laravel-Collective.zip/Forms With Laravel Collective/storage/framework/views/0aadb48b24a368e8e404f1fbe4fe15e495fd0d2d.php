<?php $__env->startSection('sidebar'); ?>
  <div class="well">
    <h3>Sidebar</h3>
    This is the sidebar
  </div>
  <?php echo $__env->yieldSection(); ?>
