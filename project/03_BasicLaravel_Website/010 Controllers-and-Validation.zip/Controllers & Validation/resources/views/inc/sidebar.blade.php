@section('sidebar')
  <div class="well">
    <h3>Sidebar</h3>
    This is the sidebar
  </div>
  @show
