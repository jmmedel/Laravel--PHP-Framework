The node_modules folder is not included. Please run the following to install..

npm install