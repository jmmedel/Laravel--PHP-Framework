<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Acme</title>
  </head>
  <body>
        @yield('content')
        @include('inc.sidebar')
  </body>
</html>
