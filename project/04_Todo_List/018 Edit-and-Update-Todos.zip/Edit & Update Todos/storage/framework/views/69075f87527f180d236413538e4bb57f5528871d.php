<?php $__env->startSection('content'); ?>
  <a class="btn btn-default" href="/">Go Back</a>
  <h1><a href="todo/<?php echo e($todo->id); ?>"><?php echo e($todo->text); ?></a></h1>
  <div class="label label-danger"><?php echo e($todo->due); ?></div>
  <hr>
  <p><?php echo e($todo->body); ?></p>
  <br><br>
  <a href="/todo/<?php echo e($todo->id); ?>/edit" class="btn btn-default">Edit</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>