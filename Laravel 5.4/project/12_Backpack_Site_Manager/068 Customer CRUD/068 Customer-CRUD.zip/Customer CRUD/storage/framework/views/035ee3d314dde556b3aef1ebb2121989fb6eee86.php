
<td><a href="mailto:<?php echo e($entry->{$column['name']}); ?>"><?php echo e($entry->{$column['name']}); ?></a></td>