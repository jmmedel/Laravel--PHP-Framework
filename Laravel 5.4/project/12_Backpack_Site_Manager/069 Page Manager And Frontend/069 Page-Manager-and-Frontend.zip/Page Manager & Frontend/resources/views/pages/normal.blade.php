@extends('layouts.app')

@section('title', $page->title);

@section('content')
  {!!$page->content!!}
@endsection
